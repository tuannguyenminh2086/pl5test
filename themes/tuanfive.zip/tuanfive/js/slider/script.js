var page_items_array = [];
var page_start_hash = '';
var $menu = '';
var $userScrolledPage = '';
	
jQuery(document).ready(function($){

	flexSliderCaption();

});

$(window).load(function() {
	
		setupFlexSlider();
  
});

